import React from 'react'
const HeaderSearchBar = () => {
  return <div></div>
}

export default HeaderSearchBar
