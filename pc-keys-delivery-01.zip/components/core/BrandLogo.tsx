import React from 'react'

const BrandLogo = () => {
  return <img src='img/logo.png' className='h-8' alt='Logo' />
}

export default BrandLogo
